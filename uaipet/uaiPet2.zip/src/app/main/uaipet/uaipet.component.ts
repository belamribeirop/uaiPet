import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-uaipet',
  templateUrl: './uaipet.component.html',
  styleUrls: ['./uaipet.component.scss']
})
export class UaipetComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
