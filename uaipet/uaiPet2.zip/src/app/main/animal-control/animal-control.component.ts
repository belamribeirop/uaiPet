import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-animal-control',
  templateUrl: './animal-control.component.html',
  styleUrls: ['./animal-control.component.scss']
})
export class AnimalControlComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
