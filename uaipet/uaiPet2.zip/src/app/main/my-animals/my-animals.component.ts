import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-animals',
  templateUrl: './my-animals.component.html',
  styleUrls: ['./my-animals.component.scss']
})
export class MyAnimalsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
